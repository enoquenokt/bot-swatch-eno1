
import json

def enviar_sinal(sinal):
    with open("frontend/sinal.json", "w") as f:
        json.dump(sinal, f)
