
from algoritmo import analisar_padrao
from servidor import enviar_sinal
import time

while True:
    # Simulação: aqui entraria a lógica de leitura real da Placard
    historico = [1.44, 2.22, 1.86, 4.60, 1.01, 53.27]
    sinal = analisar_padrao(historico)
    if sinal:
        enviar_sinal(sinal)
    time.sleep(20)
