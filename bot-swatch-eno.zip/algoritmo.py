
def analisar_padrao(historico):
    if len(historico) < 5:
        return None
    ultimos = historico[-5:]
    if all(x < 2 for x in ultimos):
        return {"cor": "rosa", "queda": "10x+", "protecao": "2x"}
    elif sum(1 for x in ultimos if x > 8) >= 2:
        return {"cor": "azul", "queda": "1.5x", "protecao": "1.2x"}
    return None
